export const TEXTS = {
  common: {
    edit: "Upravit",
    delete: "Smazat",
    email: "Email",
    phone: "Telefon",
    address: "Adresa",
    note: "Poznámka",
    ico: "IČO",
    placeholderDash: "-",
    unavailableSymbol: "❌"
  },

  schedule: {
    selectSchool: "-- vyber školu --",
    mail: "MAIL",
    plan: "P",
    reality: "S",
    hourShort: "H",
    days: ["Po", "Út", "St", "Čt", "Pá"],
    copyWeek: "Kopírovat týden",
    allTrainers: "Všichni trenéři",
    searchTrainer: "Hledat trenéra",
    copied: "Týden zkopírován",
    conflict: "Trenér už je v tento čas jinde!",
    noEmail: "Škola nemá email"
  },

  schools: {
    title: "Školy",
    detailPrompt: "Klikni na školu",
    removeConfirm: "Smazat školu?",
    contact: "Kontakt",
    favoriteTrainers: "Vybraní trenéři"
  },

  trainers: {
    title: "Trenéři",
    detailPrompt: "Klikni na trenéra",
    removeConfirm: "Smazat trenéra?",
    club: "Klub / lokalita"
  }
};
